<div>
    
    <span>Your payment has been funded successfully and transaction id(<?php echo $txn_id;?>) </span><br/>
   
</div>