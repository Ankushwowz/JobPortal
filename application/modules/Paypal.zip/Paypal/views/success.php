<div>
    <h2>Dear Member</h2>
    <span>Your payment was successfully, thank you for purchase.</span><br/>
   
</div>