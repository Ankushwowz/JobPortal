<html>
<head>
<title>Getwork</title>
</head>
<body>
<p>Notification for Verify Account</p>
<table>

<tr><a href="<?php echo base_url();?>verify-account/<?php echo base64_encode($lastId);?>">Verify Your Account</a></tr>
</table>
</body>
</html>