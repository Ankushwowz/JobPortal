<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Administrator extends MX_Controller {
	public function __construct() {
	parent::__construct();
		$this->load->library("session");
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->model("Administrator_model");
	//$this->load->module("dashboard");
	}
	public function index(){
		//echo "<pre>"; print_r("I am Here"); die;
		if(!empty($_POST['login'])){
			$this->session->set_userdata('name','test');	
			$this->form_validation->set_rules('email', 'Email','trim|valid_email|required');
			$this->form_validation->set_rules('password', 'Password', 'required');
			if($this->form_validation->run() === FALSE){
				$this->load->view('index');
			}else{
				$result = $this->Administrator_model->admin_user();
				//echo "<pre>"; print_r($result); die;
					if($result==1){
					redirect('admin-dashboard');
				}else{
					$this->session->set_flashdata('danger', 'Invaild login credentials.Please try vaild credentials');
					$this->load->view('index');
				}
			}			
		}else{
			$this->load->view('index');
		}
	}



	public function dashboard(){
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['main_content'] = 'dashboard';
		//echo "<pre>"; print_r($data['user']); die;
		$this->load->view('backend/backend-admin-layout.php',$data);
	}

	public function Userslisting(){
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['users'] = $this->Administrator_model->getUsers();
		//echo "<pre>"; print_r($data['users']); die;
		$data['title'] = 'Users Listing';
		$data['main_content'] = 'userslist';
		$this->load->view('backend/backend-admin-layout.php',$data);
	}


	public function delete(){			
			$id =$this->input->post('userid');
			$this->Administrator_model->user_delete($id);        
			echo 1;
		}

	public function change_status()	{
		$id =$this->input->post('userid');
		$this->Administrator_model->change_status($id);        
		echo 1;
	}


	public function EditProfile(){
		$data['user'] = $this->Administrator_model->getAdmin();
		//$data['usersdata'] = $this->Administrator_model->getAdmin();
		//echo "<pre>"; print_r($data['usersdata']); die;
		$data['title'] = 'dashboard';
		$data['main_content'] = 'editprofile';
		$this->load->view('backend/backend-admin-layout.php',$data);
	}



	public function AddCategory(){
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['title'] = 'Add Category';
		$data['main_content'] = 'addcategory';
		//$this->load->view('backend/backend-admin-layout.php',$data);

		if(!empty($_POST['add_category'])){
		  $this->form_validation->set_rules('category_name', 'Category Name', 'required');
			if($this->form_validation->run() === FALSE){
				$this->load->view('backend/backend-admin-layout.php', $data);
			}else{
				$result = $this->Administrator_model->AddCategory();
				if($result==1){
					$this->session->set_flashdata('success', 'Category has been added successfully.');
				}else{
					//$this->session->set_flashdata('danger', 'current password does not match with password');
				}
				redirect('add-category');
			}			
		}
		else{
			$this->load->view('backend/backend-admin-layout.php',$data);
		}

	}


	public function ViewCategory(){
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['categories'] = $this->Administrator_model->getCategory();
		//echo "<pre>"; print_r($data['users']); die;
		$data['title'] = 'Category Listing';
		$data['main_content'] = 'viewcategory';
		$this->load->view('backend/backend-admin-layout.php',$data);
	}


	public  function categorydelete(){
			$id =$this->input->post('categoryid');
			$this->Administrator_model->category_delete($id);        
			echo 1;
	}

	public function EditCategory($id){
		//echo "<pre>"; print_r($id); die;
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['categories'] = $this->Administrator_model->getSingleCategory($id);
		//echo "<pre>"; print_r($data['categories']); die;
		$data['title'] = 'Edit Category';
		$data['main_content'] = 'editcategory';	
		if(!empty($_POST['edit_category'])){
		  $this->form_validation->set_rules('category_name', 'Category Name', 'required');
			if($this->form_validation->run() === FALSE){
				$this->load->view('backend/backend-admin-layout.php', $data);
			}else{			
				$result = $this->Administrator_model->EditCategory($id);
				if($result==1){
					$this->session->set_flashdata('success', 'Category has been edited successfully.');
				}else{
					//$this->session->set_flashdata('danger', 'current password does not match with password');
				}
				redirect('view-category');
				//$this->load->view('frontend/frontend-admin-layout.php', $data);
			}			
		}
		else{
			$this->load->view('backend/backend-admin-layout.php', $data);
		}

	}


	public function AddSubCategory(){
			$data['user'] = $this->Administrator_model->getAdmin();
			$data['categories'] = $this->Administrator_model->getCategory();
			//echo "<pre>"; print_r($data['categories']); die;
			$data['title'] = 'Add Sub Category';
			$data['main_content'] = 'addsubcategory';
			//$this->load->view('backend/backend-admin-layout.php',$data);

			if(!empty($_POST['add_category'])){
			  $this->form_validation->set_rules('category_name', 'Category Name', 'required');
			  $this->form_validation->set_rules('subcategory_name', 'Sub Category Name', 'required');
				if($this->form_validation->run() === FALSE){
					$this->load->view('backend/backend-admin-layout.php', $data);
				}else{
					$result = $this->Administrator_model->AddSubCategory();
					if($result==1){
						$this->session->set_flashdata('success', 'Sub Category has been added successfully.');
					}else{
						//$this->session->set_flashdata('danger', 'current password does not match with password');
					}
					redirect('add-subcategory');
				}			
			}
			else{
				$this->load->view('backend/backend-admin-layout.php',$data);
			}

		}


		public function ViewSubCategory(){
		$data['user'] = $this->Administrator_model->getAdmin();
		//$data['categories'] = $this->Administrator_model->getCategory();
		$data['subcategories'] = $this->Administrator_model->getSubCategory();
		//echo "<pre>"; print_r($data['subcategories']); die;
		$data['title'] = 'Sub Category Listing';
		$data['main_content'] = 'viewsubcategory';
		$this->load->view('backend/backend-admin-layout.php',$data);
		}


		public  function subcategorydelete(){
			$id =$this->input->post('subcategoryid');
			$this->Administrator_model->subcategory_delete($id);        
			echo 1;
		}



		public function EditSubCategory($id){
		//echo "<pre>"; print_r($id); die;
		$data['user'] = $this->Administrator_model->getAdmin();
		$data['categories'] = $this->Administrator_model->getCategory();
		$data['subcategories'] = $this->Administrator_model->getSingleSubCategory($id);
		$data['title'] = 'Edit Sub Category';
		$data['main_content'] = 'editsubcategory';	
		if(!empty($_POST['edit_category'])){
		  $this->form_validation->set_rules('subcategory_name', 'Sub Category Name', 'required');
		  $this->form_validation->set_rules('category_name', 'Category Name', 'required');
			if($this->form_validation->run() === FALSE){
				$this->load->view('backend/backend-admin-layout.php', $data);
			}else{			
				$result = $this->Administrator_model->EditSubCategory($id);
				if($result==1){
					$this->session->set_flashdata('success', 'Sub Category has been edited successfully.');
				}else{
					//$this->session->set_flashdata('danger', 'current password does not match with password');
				}
				redirect('view-subcategory');
				//$this->load->view('frontend/frontend-admin-layout.php', $data);
			}			
		}
		else{
			$this->load->view('backend/backend-admin-layout.php', $data);
		}

	}


	function logout() {
		session_start(); 
		session_destroy();
		unset($_SESSION);
		session_regenerate_id(true);
		redirect('');
	}	



}