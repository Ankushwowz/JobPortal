<?php

class Administrator_model extends CI_Model{

    function admin_user(){

		$encrypt_password = md5($this->input->post('password')); 

		$this->db->select('id,email');

		$this->db->where('email', $this->input->post('email'));

		$this->db->where('password', $encrypt_password);

		$result = $this->db->get('admin');

		if ($result->num_rows() == 1) {

			$userData = $result->row_array();

			$Session_data = array(

							"id" =>$userData['id'],
							"email" =>$userData['email']

					);			

			$this->session->set_userdata('Session_data',$Session_data);		

			return 1;

		}else{

			return 0;

		}	

	}


	function getAdmin(){

		$UserData = $this->session->userdata('Session_data');

		$user_ID = $UserData['id'];

		$this->db->select('email,username');

		$this->db->where('id',$user_ID);

		$query = $this->db->get('admin');

		return $query->row_array();

	}


	public function getUsers(){
		$query = $this->db->get('users');
		return $query->result_array();
	}

	public function user_delete($id){
		return $this->db->where('id', $id)->delete('users');			 
	}


	/* User Status Change Start Here*/

	public function change_status(){		 
		$userid = $this->input->post('userid');
		$statusid = $this->input->post('statusid');
		$data = array(
				'status' => $statusid					  
			 	    );
	    $this->db->where('id', $userid);
		return $this->db->update('users', $data);
	}
	
	/* User Status Change End Here*/


	/***** Add Category Start Here ******/

	public function AddCategory(){
		$data = array(
						'category_name' => $this->input->post('category_name')
					);
		//echo "<pre>"; print_r($data); die;
		 //$this->db->where('id', $user_ID);
		return  $this->db->insert('category', $data);
	}

	public function getCategory(){
		$query = $this->db->get('category');
		return $query->result_array();
	}


	public function getSubCategory(){
		$this->db->select('*')->from('subcategory');
		$this->db->join('category', 'category.category_id = subcategory.category_id');
		$query = $this->db->get();
		return $query->result_array();
	}


	public function category_delete($id){
		return $this->db->where('category_id', $id)->delete('category');			 
	}

	public function getSingleCategory($id){
		$query = $this->db->where('category_id',$id)->get('category');
		return $result = $query->row_array();
	}

	function EditCategory($id){
		//$id = base64_decode($id);		
			$userData = array(
							'category_name' => $this->input->post('category_name'),							
						);
			$this->db->where('category_id',$id);
			return $this->db->update('category', $userData);

	}


	public function AddSubCategory(){
		$data = array(
						'category_id' => $this->input->post('category_name'),
						'subcategory_name' => $this->input->post('subcategory_name')
					);
		//echo "<pre>"; print_r($data); die;
		 //$this->db->where('id', $user_ID);
		return  $this->db->insert('subcategory', $data);
	}


	public function subcategory_delete($id){
		return $this->db->where('subcategory_id', $id)->delete('subcategory');			 
	}

	public function getSingleSubCategory($id){
		$query = $this->db->where('subcategory_id',$id)->get('subcategory');
		return $result = $query->row_array();
	}

	function EditSubCategory($id){
		//$id = base64_decode($id);		
			$userData = array(
							'category_id' => $this->input->post('category_name'),							
							'subcategory_name' => $this->input->post('subcategory_name')							
						);
			$this->db->where('subcategory_id',$id);
			return $this->db->update('subcategory', $userData);

	}	

	/***** Add Category End Here ******/


}



?>