<html>
<head>
<title>Getwork</title>
</head>
<body>
<p>Thank you for signing up with Getwork Global. Please click on the link below to verify & activate your account.</p>
<table>

<tr><a href="<?php echo base_url();?>verify-account/<?php echo base64_encode($lastId);?>">Verify Your Account</a></tr>
</table>
</body>
</html>