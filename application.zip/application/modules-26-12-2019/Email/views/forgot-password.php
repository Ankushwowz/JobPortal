<html>
<head>
<title>Getwork</title>
</head>
<body>
<p>Notification of New Password</p>
<table>

<tr><td><b>New password</b></td><td><?php if(!empty($password)) { echo $password;}?></td></tr>

</table>
</body>
</html>