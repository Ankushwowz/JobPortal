<div class="row">
    <div class="col-md-12" style="    font-size: 18px;margin: 50px 0 0 44px;">
    	<span>Your payment has been funded successfully and transaction id(<b><?php echo $txn_id;?></b>) </span><br/>
    </div>
    
   
</div>