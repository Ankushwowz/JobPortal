<?php

namespace Stripe\Error;

class RateLimit extends InvalidRequest
{
}
