<?php
/*function get_header($method = 'index'){
	echo modules::run("general/header/".$method);
}
function get_footer($method = 'index'){
	echo modules::run("general/footer/".$method);
}*/
?>